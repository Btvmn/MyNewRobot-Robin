package MyNewRobot;
import robocode.*;
import robocode.util.Utils;

import java.awt.Color;

/**
 * MyRobot - a robot by (Bohdan M)
 */

public class MyNewRobot extends AdvancedRobot {
    private int count = 0; // counting variable for the movement
    private double lastEnemyEnergy = 0;
    private double dir = 1; // 1 means running forward, -1 backward

    public void run() {

        // set colors
        setColors(Color.red, Color.blue, Color.cyan);
        setBulletColor(Color.orange);

        // Make robot, gun, and radar turn independently of each other
        setAdjustGunForRobotTurn(true);
        setAdjustRadarForGunTurn(true);
        setAdjustRadarForRobotTurn(true);

        // Turn the radar around as fast as possible (the limit is 45
        // degree/tick)
        setTurnRadarRightRadians(Double.POSITIVE_INFINITY);

        // The movement loop
        while (true) {
            // Bizarre movement
            System.out.println(count++);
            if (getDistanceRemaining() == 0 && getTurnRemaining() == 0) {
                if (count % 50 < 8)
                    setAhead(30*dir);
                else
                    setAhead(10*dir);

                if (count % 50 < 8) {
                    setTurnLeft(10);
                } else {
                    setTurnRight(10);
                }
            }

            // onScannedRobot is not sent if the enemy stands still
            // So we need to explicitly call scan()
            execute();
            scan();

            // If somehow the radar stops, we must turn it again
            if (getRadarTurnRemaining() == 0) {
                setTurnRadarLeft(Double.POSITIVE_INFINITY);
            }
        }
    }

    /**
     * onScannedRobot: What to do when we see another robot
     */
    public void onScannedRobot(ScannedRobotEvent e) {


        // Decide how strong the bullet is depending on enemy's distance
        double power;
        double d = e.getDistance();
        power = 3.0 * Math.exp(-0.002 * (d - 50));
        if (power > 3)
            power = 3;
        else if (power < 0.1)
            power = 0.1;

        // Calculate bullet's speed
        double v = 20 - (power * 3);

        // Radar tracking by turning the radar to enemy's last direction
        double radarTurn = getHeadingRadians() + e.getBearingRadians() - getRadarHeadingRadians();
        // Chop angle to range
        setTurnRadarRightRadians(1.9 * Utils.normalRelativeAngle(radarTurn));

        // Approximate linear aim-ahead assuming velocity vector is constant
        // beta = arcsin(V/v * sin(alpha))
        // beta: angle to turn
        // V: enemy's velocity
        // v: bullet's velocity
        // alpha: angle between enemy's direction from us and enemy's heading
        double gunTurn = getHeadingRadians() + e.getBearingRadians() - getGunHeadingRadians();
        double alpha = e.getHeadingRadians() - (getHeadingRadians() + e.getBearingRadians());
        gunTurn += Math.asin(e.getVelocity() * Math.sin(alpha) / v);
        // Chop angle to  range
        setTurnGunRightRadians(Utils.normalRelativeAngle(gunTurn));

        // Fire after turning the gun
        // If power is less than 2, there's a chance we don't shoot
        // TODO: this should be based directly on distance
        if (Math.random() < power/2) {
            setFire(power);
        }

        // Keep track of enemy's energy assuming 1-on-1
        double enemyEnergyLost = lastEnemyEnergy - e.getEnergy();
        lastEnemyEnergy = e.getEnergy();

        if (getDistanceRemaining() > 5 || getTurnRemaining() > 0) {
            // If we are in a motion already, simple continue with it
            // 5 is for a smooth movement, we don't want to completely stop before moving again
            return;
        } else if (enemyEnergyLost < 3 && enemyEnergyLost > 1) {
            // Assume they fired if energy lost is 1-3
            // Quickly go aside, but not exactly perpendicular
            double tankTurn = e.getBearing() + 60;
            System.out.println("They fired!");
            setTurnRight(Utils.normalRelativeAngleDegrees(tankTurn));
            // NOTE: changing direction like this invalidated the above comment if dir < 0
            setAhead(100*dir);
        } else if (d > 100) {
            // Too far from them
            // Go toward, but not straight-forward, slightly to the side
            double tankTurn = e.getBearing() + 25;
            setTurnRight(Utils.normalRelativeAngleDegrees(tankTurn));
            // NOTE: changing direction like this invalidated the above comment if dir < 0
            setAhead(30*dir);
        } else {
            // Not too far, not being fired at
            // Circle them (90 means perpendicular to their direction)
            double tankTurn = e.getBearing() + 90;
            setTurnRight(Utils.normalRelativeAngleDegrees(tankTurn));
            setAhead(30*dir);           
        }
        
        // Do all the above then scan
        execute();
        scan();
    }

    /**
     * onHitByBullet: What to do when we're hit by a bullet
     */
    public void onHitByBullet(HitByBulletEvent e) {

        // If he's in front of us, set back up a bit.
        if (e.getBearing() > -90 && e.getBearing() < 90) {
            back(100);
        }
        // else he's in back of us, so set ahead a bit.
        else {
            ahead(100);
        }
    }

    /**
     * onHitWall: What to do when we hit the wall
     */
    public void onHitWall(HitWallEvent e) {
        // Go back if we hit the wall
        dir *= -1;
    }
} //finish
